# Default work stream of AutoMR:
# R/UHF (Gaussian16) -> UNO (PySCF) -> GVB (GAMESS-US) -> CASSCF (PySCF) [-> CASPT2 (OpenMolcas)]
mem='96GB'
mokitkeys='gvb_conv=1d-4'

# Skip MOKIT job and directly run PySCF CASSCF/DMRG-SCF job.
direct=True

readfch='guess.fch' # Read wavefunction as initial guess.
typefch='CAS-NO' # HF, NO or CAS-NO.
           # HF: run ist=1/3; NO: run ist=5; CAS-NO: run PySCF-CASSCF job.

# For MECP optimization with XMECP.
# Please use "runpyscf.py" or "runchemsh_pyscf.py" modules in XMECP.
# If you do not have these modules, please contact the developers.
mecp=True

force=True # Whether MRSCF gradient is needed. Set as True for optimization.
           # force=False means a single point job.

jobtype='CASSCF/def2SVP'

state_specific=False # For excited state, False means using SA-CASSCF.
                     # You must set "state_specific=False" for MECP optimization.

# Fragment settings.
fragment=False
# The fragment id should be corresponding to ids of QM region, but except linker atoms.
frags=[['1-14',-2,1],
       ['32-43',-1,1],
       ['61',2,5],
       ['62-63',0,-3],
       ['15-31 44-60',0,1]] # Atom list, charge and multiplicity.

# Default AutoMR stream is ist=3/1 for R/UHF.
# If you want to use other stream, please modify the source code. (e.g. ist=2 to skip GVB calculation)

# ---------------------------------------------------------------------------------------------------------------------------------- #
# -------------------------------- Do not modify following section unless for development usage !!! -------------------------------- #
# ---------------------------------------------------------------------------------------------------------------------------------- #

# # How to obtain reference state. Default: RHF/UHF.
# # If you want to calculate reference state wavefunction by yourself, specify "refcalc=True" here.
# refcalc=False
# reftype='rhf' # rks, uks, uhf, rhf, rohf, roks (uks and roks are not recommanded)
# software='g16' # g16, orca

# Gaussian16 keywords that will be automatically added:
# NoSymm Int(NoBasisTransform) 5d 7f Charge [Guess=Read]
g16keys='UHF 6-31G(d) SCF(MaxCycle=512,XQC) Stable=Opt'
orcakeys='Unrestricted HF 6-31G(d)' # To be implemented.

addocc,addvir=0,0

norb,nele=304,112 # Added by mokit_interface.py at first step.
norb,nele=6,6 # Added by mokit_interface.py at first step.
